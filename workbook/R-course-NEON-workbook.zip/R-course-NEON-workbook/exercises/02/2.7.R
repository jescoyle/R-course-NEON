# Write R code that calculates:
  
# 1. The area of a circle with radius = 5.
#    HINT: The variable `pi` contains the value of the number pi. 
#    Type `pi` into the console to see this.


# 2. The area of circles with radii = to the numbers 1 through 100.



# 3. The average of the areas of the 100 circles calculated in step 2.
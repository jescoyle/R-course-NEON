
A <- c(1, 2, 3, "4")

B <- c(TRUE, FALSE, FALSE, NA)

C <- factor(A)

dat1 <- list(A = A, B = B, C = C)

dat2 <- data.frame(A, B, C)


# 1. What is the data type of object A in the code above? Why doesn't it have two data types?
# ANSWER:


# 2. Write one line of code that prints the data type of the object A.
X <- c(0, 0, 2.8, 5)

Y <- matrix(X, nrow = 2, ncol = 4)

Z <- array(X, dim = c(2, 4, 3))

# 1. Using the objects above, write one line of code that calculates 
#    the product of the 3rd element of X and the second row of Y. 


# 2. What type of object is the result?
# ANSWER:


# 3. What are the dimensions of the result?
# ANSWER:
# 1. Read in the data in the file `data/NEON_water/waterqual_inst_TECR_2021-04_2021-10.csv` 
# to a data frame.


# 2. Save the column names to a vector named WQnames


# 3. Print the dimensions of these data (e.g. how many rows and columns).



# 4. Print the last 10 rows of these data from the fDOM and chlorophyll columns.
# Write code that accomplishes the following:

# 1. Calculate the average of all even numbers from 1 to 100 and assign this value to a variable.


# 2. Calculate the average of all odd numbers from 1 to 100 and assign this value to a different variable.


# 3. Calculate the difference between the two variables you created (i.e. subtract them).
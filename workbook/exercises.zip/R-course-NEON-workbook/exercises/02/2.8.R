# Use the following code to answer the questions:
  
dogs <- c("Alphie", "Boo", "Carter")

cats <- c("Donut", "Edgar", "Felix")


# Write one line of code for each of the following:
  
# 1. Select the second name in `dogs`.



# 2. Replace the first and third names in `cats` with a value that indicates the data are missing.
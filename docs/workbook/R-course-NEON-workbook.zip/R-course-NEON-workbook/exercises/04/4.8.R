# What class are each of the following objects? 
# ANSWER:

# How are these classes similar? 
# ANSWER:


# How are they different?
# ANSWER:

  
X <- c(0, 0, 2.8, 5)

Y <- matrix(X, nrow = 2, ncol = 4)

Z <- array(X, dim = c(2, 4, 3))